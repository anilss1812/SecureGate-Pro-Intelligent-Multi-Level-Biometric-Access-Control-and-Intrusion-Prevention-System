lcd.o: lcd.c
lcd.o: C:\KeilARM\ARM\INC\Philips\LPC21xx.h
lcd.o: types.h
lcd.o: lcd.h
lcd.o: types.h
lcd.o: lcd_defines.h
lcd.o: delay.h
