log.o: log.c
log.o: C:\KeilARM\ARM\INC\Philips\LPC21xx.H
log.o: log.h
log.o: lcd.h
log.o: types.h
log.o: lcd_defines.h
