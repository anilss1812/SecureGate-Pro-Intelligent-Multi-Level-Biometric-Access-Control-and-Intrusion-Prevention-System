fingerprint.o: fingerprint.c
fingerprint.o: uart.h
fingerprint.o: types.h
fingerprint.o: lcd.h
fingerprint.o: types.h
fingerprint.o: delay.h
fingerprint.o: lcd_defines.h
