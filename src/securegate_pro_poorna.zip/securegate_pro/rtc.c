#include <lpc214x.h>
#include "types.h"
#include "lcd.h"
#include "lcd_defines.h"

#define PCLK 15000000
#define PREINT_VALUE ((PCLK/32768)-1)
#define PREFRAC_VALUE (PCLK-((PREINT_VALUE+1)*32768))

void RTC_Init(void) 
{
 CCR=1<<1;//reset
	PREINT=PREINT_VALUE;
	PREFRAC=PREFRAC_VALUE;
	CCR=1<<0;//RTC is enable	
}
