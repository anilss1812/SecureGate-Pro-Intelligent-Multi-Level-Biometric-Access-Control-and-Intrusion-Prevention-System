motor.o: motor.c
motor.o: C:\KeilARM\ARM\INC\Philips\lpc21xx.h
motor.o: motor.h
motor.o: types.h
motor.o: delay.h
