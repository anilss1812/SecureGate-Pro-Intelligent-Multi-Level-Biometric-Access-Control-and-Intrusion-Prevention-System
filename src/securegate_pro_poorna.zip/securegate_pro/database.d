database.o: database.c
database.o: database.h
database.o: types.h
database.o: i2c_eeprom.h
database.o: types.h
database.o: C:\KeilARM\ARM\RV31\INC\string.h
