void RTC_Init(void);
