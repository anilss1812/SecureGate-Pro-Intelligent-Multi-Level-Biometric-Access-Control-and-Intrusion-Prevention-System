uart.o: uart.c
uart.o: C:\KeilARM\ARM\INC\Philips\lpc21xx.h
uart.o: types.h
uart.o: uart_defines.h
