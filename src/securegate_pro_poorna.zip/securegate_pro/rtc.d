rtc.o: rtc.c
rtc.o: C:\KeilARM\ARM\INC\Philips\lpc214x.h
rtc.o: types.h
rtc.o: lcd.h
rtc.o: types.h
rtc.o: lcd_defines.h
