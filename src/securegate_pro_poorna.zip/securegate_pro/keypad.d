keypad.o: keypad.c
keypad.o: C:\KeilARM\ARM\INC\Philips\lpc21xx.h
keypad.o: types.h
keypad.o: keypad_defines.h
